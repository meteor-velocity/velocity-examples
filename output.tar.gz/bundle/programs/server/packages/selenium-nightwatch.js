(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/selenium-nightwatch/velocity-integration.js                                                        //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
;(function () {                                                                                                // 1
                                                                                                               // 2
  "use strict";                                                                                                // 3
  console.log('welcome to Nighwatch-Selenium...')                                                              // 4
                                                                                                               // 5
  if ('undefined' !== typeof Mirror && Mirror.isMirror) {                                                      // 6
    // only run jasmine unit tests once, not for each mirror                                                   // 7
    return;                                                                                                    // 8
  }                                                                                                            // 9
                                                                                                               // 10
  var ANNOUNCE_STRING = 'Velocity Nightwatch-Selenium is loaded',                                              // 11
      pwd = process.env.PWD,                                                                                   // 12
      DEBUG = process.env.NIGHTWATCH_DEBUG,                                                                    // 13
      spawn = Npm.require('child_process').spawn,                                                              // 14
      parseString = Npm.require('xml2js').parseString,                                                         // 15
      glob = Npm.require('glob'),                                                                              // 16
      fs = Npm.require('fs'),                                                                                  // 17
      path = Npm.require('path'),                                                                              // 18
      _ = Npm.require('lodash'),                                                                               // 19
      rimraf = Npm.require('rimraf'),                                                                          // 20
      //testReportsPath = path.join(pwd, 'tests', '.reports', 'jasmine-unit'),                                 // 21
      testReportsPath = path.join(pwd, 'tests', '.reports', 'nightwatch-acceptance'),                          // 22
      args = [],                                                                                               // 23
      consoleData = '',                                                                                        // 24
      jasmineCli,                                                                                              // 25
      closeFunc;                                                                                               // 26
                                                                                                               // 27
                                                                                                               // 28
// build OS-independent path to jasmine cli                                                                    // 29
  //jasmineCli = pwd + ',packages,jasmine-unit,.npm,package,node_modules,jasmine-node,lib,jasmine-node,cli.js'.split(',').join(path.sep);
  var nightwatchCli = pwd + '/run_nightwatch.sh';                                                              // 31
                                                                                                               // 32
  args.push(nightwatchCli);                                                                                    // 33
                                                                                                               // 34
  //args.push(jasmineCli);                                                                                     // 35
  // args.push('--coffee');                                                                                    // 36
  // args.push('--color');                                                                                     // 37
  // args.push('--verbose');                                                                                   // 38
  // args.push('--match');                                                                                     // 39
  // args.push('.*-jasmine-unit\.');                                                                           // 40
  // args.push('--matchall');                                                                                  // 41
  // args.push('--junitreport');                                                                               // 42
  // args.push('--output');                                                                                    // 43
  // args.push(testReportsPath);                                                                               // 44
  // args.push(path.join(pwd, 'packages', 'jasmine-unit', 'lib'));                                             // 45
  // args.push(path.join(pwd, 'tests'));                                                                       // 46
                                                                                                               // 47
  // How can we abstract this server-side so the test frameworks don't need to know about velocity collections // 48
  // VelocityTestFiles.find({targetFramework: 'nightwatch'}).observe({                                         // 49
  //   added: rerunTests,                                                                                      // 50
  //   changed: rerunTests,                                                                                    // 51
  //   removed: rerunTests                                                                                     // 52
  // });                                                                                                       // 53
                                                                                                               // 54
  //rerunTests();                                                                                              // 55
  parseOutputFiles();                                                                                          // 56
  console.log(ANNOUNCE_STRING);                                                                                // 57
                                                                                                               // 58
                                                                                                               // 59
                                                                                                               // 60
//////////////////////////////////////////////////////////////////////                                         // 61
// private functions                                                                                           // 62
//                                                                                                             // 63
                                                                                                               // 64
  function hashCode (s) {                                                                                      // 65
    return s.split("").reduce(function (a, b) {                                                                // 66
      a = ((a << 5) - a) + b.charCodeAt(0);                                                                    // 67
      return a & a;                                                                                            // 68
    }, 0);                                                                                                     // 69
  }                                                                                                            // 70
                                                                                                               // 71
  // possible memory leak                                                                                      // 72
  var regurgitate = Meteor.bindEnvironment(function (data) {                                                   // 73
    consoleData += data;                                                                                       // 74
    if (consoleData.indexOf('\n') !== -1 && consoleData.trim()) {                                              // 75
      console.log(consoleData.trim());                                                                         // 76
      Meteor.call('postLog', {                                                                                 // 77
        type: 'out',                                                                                           // 78
        framework: 'nightwatch',                                                                               // 79
        message: consoleData.trim()                                                                            // 80
      });                                                                                                      // 81
      consoleData = '';                                                                                        // 82
    }                                                                                                          // 83
  });                                                                                                          // 84
                                                                                                               // 85
  // closeFunc = Meteor.bindEnvironment(function () {                                                          // 86
  //   var newResults = [],                                                                                    // 87
  //       globSearchString = path.join('**', 'FIREFOX-*.xml'),                                                // 88
  //       xmlFiles = glob.sync(globSearchString, { cwd: testReportsPath });                                   // 89
  //                                                                                                           // 90
  //   _.each(xmlFiles, function (xmlFile, index) {                                                            // 91
  //     parseString(fs.readFileSync(testReportsPath + path.sep + xmlFile), function (err, result) {           // 92
  //       _.each(result.testsuites.testsuite, function (testsuite) {                                          // 93
  //         _.each(testsuite.testcase, function (testcase) {                                                  // 94
  //           var result = ({                                                                                 // 95
  //             name: testcase.$.name,                                                                        // 96
  //             framework: 'nightwatch',                                                                      // 97
  //             result: testcase.failure ? 'failed' : 'passed',                                               // 98
  //             timestamp: testsuite.$.timestamp,                                                             // 99
  //             time: testcase.$.time,                                                                        // 100
  //             ancestors: [testcase.$.classname]                                                             // 101
  //           });                                                                                             // 102
  //                                                                                                           // 103
  //           if (testcase.failure) {                                                                         // 104
  //             _.each(testcase.failure, function (failure) {                                                 // 105
  //               result.failureType = failure.$.type;                                                        // 106
  //               result.failureMessage = failure.$.message;                                                  // 107
  //               result.failureStackTrace = failure._;                                                       // 108
  //             });                                                                                           // 109
  //           }                                                                                               // 110
  //           result.id = 'nightwatch:' + hashCode(xmlFile + testcase.$.classname + testcase.$.name);         // 111
  //           newResults.push(result.id);                                                                     // 112
  //           Meteor.call('postResult', result);                                                              // 113
  //         });                                                                                               // 114
  //       });                                                                                                 // 115
  //     });                                                                                                   // 116
  //                                                                                                           // 117
  //     if (index === xmlFiles.length - 1) {                                                                  // 118
  //       Meteor.call('resetReports', {framework: 'nightwatch', notIn: newResults});                          // 119
  //       Meteor.call('completed', {framework: 'nightwatch'});                                                // 120
  //     }                                                                                                     // 121
  //   });                                                                                                     // 122
  // });  // end closeFunc                                                                                     // 123
                                                                                                               // 124
  function parseOutputFiles(){                                                                                 // 125
    console.log('parsing Nightwatch output files...');                                                         // 126
    //Meteor.bindEnvironment(function (data) {                                                                 // 127
    //console.log('bound environment...');                                                                     // 128
      var newResults = [],                                                                                     // 129
          globSearchString = path.join('**', 'FIREFOX_*.xml'),                                                 // 130
          xmlFiles = glob.sync(globSearchString, { cwd: testReportsPath });                                    // 131
                                                                                                               // 132
    console.log('globSearchString: ' + globSearchString);                                                      // 133
      console.log('testReportsPath: ' + testReportsPath);                                                      // 134
                                                                                                               // 135
      console.log('iterating through files...');                                                               // 136
      _.each(xmlFiles, function (xmlFile, index) {                                                             // 137
        console.log('xmlfile ' + index + ": " + xmlFile);                                                      // 138
                                                                                                               // 139
        parseString(fs.readFileSync(testReportsPath + path.sep + xmlFile), function (err, result) {            // 140
          _.each(result.testsuites.testsuite, function (testsuite) {                                           // 141
            _.each(testsuite.testcase, function (testcase) {                                                   // 142
              var result = ({                                                                                  // 143
                name: testcase.$.name,                                                                         // 144
                framework: 'nightwatch',                                                                       // 145
                result: testcase.failure ? 'failed' : 'passed',                                                // 146
                timestamp: testsuite.$.timestamp,                                                              // 147
                time: testcase.$.time,                                                                         // 148
                ancestors: [testcase.$.classname]                                                              // 149
              });                                                                                              // 150
                                                                                                               // 151
              if (testcase.failure) {                                                                          // 152
                _.each(testcase.failure, function (failure) {                                                  // 153
                  result.failureType = failure.$.type;                                                         // 154
                  result.failureMessage = failure.$.message;                                                   // 155
                  result.failureStackTrace = failure._;                                                        // 156
                });                                                                                            // 157
              }                                                                                                // 158
              result.id = 'nightwatch:' + hashCode(xmlFile + testcase.$.classname + testcase.$.name);          // 159
              newResults.push(result.id);                                                                      // 160
              Meteor.call('postResult', result);                                                               // 161
            });                                                                                                // 162
          });                                                                                                  // 163
        });                                                                                                    // 164
                                                                                                               // 165
        if (index === xmlFiles.length - 1) {                                                                   // 166
          Meteor.call('resetReports', {framework: 'nightwatch', notIn: newResults});                           // 167
          Meteor.call('completed', {framework: 'nightwatch'});                                                 // 168
        }                                                                                                      // 169
      });                                                                                                      // 170
    //});                                                                                                      // 171
  }                                                                                                            // 172
                                                                                                               // 173
                                                                                                               // 174
  // function rerunTests () {                                                                                  // 175
  //   Meteor.call('resetLogs', {framework: 'nightwatch'});                                                    // 176
  //   rimraf.sync(testReportsPath);                                                                           // 177
  //                                                                                                           // 178
  //   // PackageStubber.stubPackages({                                                                        // 179
  //   //   outfile: path.join('tests', 'a1-package-stub.js')                                                  // 180
  //   // })                                                                                                   // 181
  //                                                                                                           // 182
  //   var nightwatchNode = spawn(process.execPath, args);                                                     // 183
  //   nightwatchNode.stdout.on('data', regurgitate);                                                          // 184
  //   nightwatchNode.stderr.on('data', regurgitate);                                                          // 185
  //   nightwatchNode.on('close', closeFunc);                                                                  // 186
  // }                                                                                                         // 187
                                                                                                               // 188
                                                                                                               // 189
})();                                                                                                          // 190
                                                                                                               // 191
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['selenium-nightwatch'] = {};

})();

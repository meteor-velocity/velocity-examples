(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var VelocityTestFiles = Package.velocity.VelocityTestFiles;
var VelocityTestReports = Package.velocity.VelocityTestReports;
var VelocityAggregateReports = Package.velocity.VelocityAggregateReports;
var VelocityLogs = Package.velocity.VelocityLogs;

/* Package-scope variables */
var MochaWeb, MeteorCollectionTestReporter, ddpParentConnection, wrappedFunc, boundWrappedFunction;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// packages/mocha-web-velocity/reporter.js                                                   //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
MochaWeb = {};                                                                               // 1
                                                                                             // 2
if (Meteor.isServer)                                                                         // 3
  var Base = Npm.require("mocha/lib/reporters").Base;                                        // 4
else                                                                                         // 5
  Base = Mocha.reporters.Base                                                                // 6
                                                                                             // 7
function getAncestors(testObject, ancestors){                                                // 8
  if (!ancestors)                                                                            // 9
    ancestors = []                                                                           // 10
  if (testObject.parent && testObject.parent.title !== ""){                                  // 11
    ancestors.push(testObject.parent.title)                                                  // 12
    return getAncestors(testObject.parent, ancestors);                                       // 13
  }                                                                                          // 14
  else{                                                                                      // 15
    return ancestors;                                                                        // 16
  }                                                                                          // 17
};                                                                                           // 18
                                                                                             // 19
MochaWeb.MeteorCollectionTestReporter = function(runner){                                    // 20
  Base.call(this, runner);                                                                   // 21
  var self = this;                                                                           // 22
                                                                                             // 23
  function saveTestResult(test){                                                             // 24
    if (test.state === "failed"){                                                            // 25
      console.log(test.err.message);                                                         // 26
      console.log(test.err.stack);                                                           // 27
    }                                                                                        // 28
                                                                                             // 29
    // console.log("SAVE TEST RESULT", test);                                                // 30
                                                                                             // 31
    var result = {                                                                           // 32
      id: "mocha:" + Meteor.uuid(),                                                          // 33
      async: test.async,                                                                     // 34
      framework: "mocha-web-velocity",                                                       // 35
      name: test.title,                                                                      // 36
      pending: test.pending,                                                                 // 37
      result: test.state,                                                                    // 38
      time: test.duration,                                                                   // 39
      timeOut: test._timeout,                                                                // 40
      timedOut: test.timedOut,                                                               // 41
      ancestors: getAncestors(test),                                                         // 42
      timestamp: new Date().toTimeString()                                                   // 43
    }                                                                                        // 44
    if (test.err){                                                                           // 45
      result.failureMessage = test.err.message;                                              // 46
      result.failureStackTrace = test.err.stack;                                             // 47
    }                                                                                        // 48
    // console.log("POSTING RESULT", result);                                                // 49
                                                                                             // 50
    ddpParentConnection.call("postResult", result, function(error, result){                  // 51
      if (error){                                                                            // 52
        console.error("ERROR WRITING TEST", error);                                          // 53
      }                                                                                      // 54
    });                                                                                      // 55
  }                                                                                          // 56
                                                                                             // 57
  runner.on("start", Meteor.bindEnvironment(                                                 // 58
    function(){                                                                              // 59
      //TODO tell testRunner that mocha tests have started                                   // 60
    },                                                                                       // 61
    function(err){                                                                           // 62
      throw err;                                                                             // 63
    }                                                                                        // 64
  ));                                                                                        // 65
                                                                                             // 66
  ["pass", "fail", "pending"].forEach(function(testEvent){                                   // 67
    runner.on(testEvent, Meteor.bindEnvironment(                                             // 68
      function(test){                                                                        // 69
        saveTestResult(test);                                                                // 70
      },                                                                                     // 71
      function(err){                                                                         // 72
        throw err;                                                                           // 73
      }                                                                                      // 74
    ));                                                                                      // 75
  });                                                                                        // 76
                                                                                             // 77
  runner.on('end', Meteor.bindEnvironment(function(){                                        // 78
    //TODO tell testRunner all mocha web tests have finished                                 // 79
  }, function(err){                                                                          // 80
    throw err;                                                                               // 81
  }));                                                                                       // 82
};                                                                                           // 83
                                                                                             // 84
///////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// packages/mocha-web-velocity/server.js                                                     //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
if (!process.env.NODE_ENV === "development"){                                                // 1
  console.log("process.env.NODE ENV != DEVELOPMENT, TESTS WILL NOT BE RAN");                 // 2
}                                                                                            // 3
else {                                                                                       // 4
  var clientTestsComplete = false;                                                           // 5
  var serverTestsComplete = false;                                                           // 6
                                                                                             // 7
  var Mocha = Npm.require("mocha");                                                          // 8
  var Fiber = Npm.require("fibers");                                                         // 9
  var _ = Npm.require("underscore");                                                         // 10
  var childProcess = Npm.require('child_process');                                           // 11
  var path = Npm.require('path');                                                            // 12
  var mkdirp = Npm.require("mkdirp");                                                        // 13
                                                                                             // 14
  ddpParentConnection = null;                                                                // 15
  var parentUrl = null;                                                                      // 16
  var childUrl = null;                                                                       // 17
                                                                                             // 18
  Meteor.startup(function(){                                                                 // 19
    if (process.env.IS_MIRROR) {                                                             // 20
      console.log("MOCHA-WEB MIRROR LISTENING AT", process.env.ROOT_URL);                    // 21
      parentUrl = process.env.PARENT_URL;                                                    // 22
      console.log("PARENT URL", process.env.PARENT_URL);                                     // 23
      ddpParentConnection = DDP.connect(parentUrl);                                          // 24
      console.log("Running mocha-web-velocity server tests");                                // 25
      mocha.run(function(err){                                                               // 26
        serverTestsComplete = true;                                                          // 27
        if (clientTestsComplete){                                                            // 28
          markTestsComplete();                                                               // 29
        }                                                                                    // 30
      });                                                                                    // 31
    }                                                                                        // 32
  });                                                                                        // 33
                                                                                             // 34
  function markTestsComplete(){                                                              // 35
    ddpParentConnection.call("completed", {framework: "mocha-web-velocity"}, function(err){  // 36
      if (err){                                                                              // 37
        console.error("error calling testsComplete function", err);                          // 38
      }                                                                                      // 39
    });                                                                                      // 40
  }                                                                                          // 41
                                                                                             // 42
  Meteor.methods({                                                                           // 43
    "mirrorInfo": function(){                                                                // 44
      return {                                                                               // 45
        isMirror: process.env.IS_MIRROR,                                                     // 46
        parentUrl: process.env.PARENT_URL                                                    // 47
      }                                                                                      // 48
    },                                                                                       // 49
                                                                                             // 50
    "clientTestsComplete": function(){                                                       // 51
      // console.log("CLIENT TESTS COMPLETE");                                               // 52
      clientTestsComplete = true;                                                            // 53
      if (serverTestsComplete){                                                              // 54
        markTestsComplete();                                                                 // 55
      }                                                                                      // 56
    }                                                                                        // 57
  })                                                                                         // 58
                                                                                             // 59
  //if not a mirror don't do anything                                                        // 60
  MochaWeb.testOnly = function(callback){                                                    // 61
    // console.log("NO OP", mirror.isMirror);                                                // 62
  };                                                                                         // 63
                                                                                             // 64
  setupMocha();                                                                              // 65
                                                                                             // 66
  function setupMocha(){                                                                     // 67
    if (! process.env.IS_MIRROR)                                                             // 68
      return;                                                                                // 69
    // console.log("Enabling MochaWeb.testOnly");                                            // 70
    //only when mocha has been explicity enabled (in a mirror)                               // 71
    //do we run the tests                                                                    // 72
    MochaWeb.testOnly = function(callback){                                                  // 73
      callback();                                                                            // 74
    }                                                                                        // 75
                                                                                             // 76
    global.chai = Npm.require("chai");                                                       // 77
                                                                                             // 78
    global.mocha = new Mocha({ui: "bdd", reporter: MochaWeb.MeteorCollectionTestReporter});  // 79
    console.log("SETUP GLOBALS");                                                            // 80
    setupGlobals();                                                                          // 81
  }                                                                                          // 82
                                                                                             // 83
  function setupGlobals(){                                                                   // 84
    //basically a direct copy from meteor/packages/meteor/dynamics_nodejs.js                 // 85
    //except the wrapped function has an argument (mocha distinguishes                       // 86
    //asynchronous tests from synchronous ones by the "length" of the                        // 87
    //function passed into it, before, etc.)                                                 // 88
    var moddedBindEnvironment = function (func, onException, _this) {                        // 89
      if (!Fiber.current)                                                                    // 90
        throw new Error(noFiberMessage);                                                     // 91
                                                                                             // 92
      var boundValues = _.clone(Fiber.current._meteor_dynamics || []);                       // 93
                                                                                             // 94
      if (!onException || typeof(onException) === 'string') {                                // 95
        var description = onException || "callback of async function";                       // 96
        onException = function (error) {                                                     // 97
          Meteor._debug(                                                                     // 98
            "Exception in " + description + ":",                                             // 99
            error && error.stack || error                                                    // 100
          );                                                                                 // 101
        };                                                                                   // 102
      }                                                                                      // 103
                                                                                             // 104
      //note the callback variable present here                                              // 105
      return function (callback) {                                                           // 106
        var args = _.toArray(arguments);                                                     // 107
                                                                                             // 108
        var runWithEnvironment = function () {                                               // 109
          var savedValues = Fiber.current._meteor_dynamics;                                  // 110
          try {                                                                              // 111
            // Need to clone boundValues in case two fibers invoke this                      // 112
            // function at the same time                                                     // 113
            Fiber.current._meteor_dynamics = _.clone(boundValues);                           // 114
            var ret = func.apply(_this, args);                                               // 115
          } catch (e) {                                                                      // 116
            onException(e);                                                                  // 117
          } finally {                                                                        // 118
            Fiber.current._meteor_dynamics = savedValues;                                    // 119
          }                                                                                  // 120
          return ret;                                                                        // 121
        };                                                                                   // 122
                                                                                             // 123
        if (Fiber.current)                                                                   // 124
          return runWithEnvironment();                                                       // 125
        Fiber(runWithEnvironment).run();                                                     // 126
      };                                                                                     // 127
    };                                                                                       // 128
                                                                                             // 129
                                                                                             // 130
    var mochaExports = {};                                                                   // 131
    mocha.suite.emit("pre-require", mochaExports);                                           // 132
    //console.log(mochaExports);                                                             // 133
                                                                                             // 134
    //patch up describe function so it plays nice w/ fibers                                  // 135
    global.describe = function (name, func){                                                 // 136
      mochaExports.describe(name, Meteor.bindEnvironment(func, function(err){throw err; })); // 137
    };                                                                                       // 138
                                                                                             // 139
    //In Meteor, these blocks will all be invoking Meteor code and must                      // 140
    //run within a fiber. We must therefore wrap each with something like                    // 141
    //bindEnvironment. The function passed off to mocha must have length                     // 142
    //greater than zero if we want mocha to run it asynchronously. That's                    // 143
    //why it uses the moddedBindEnivronment function described above instead                 // 144
                                                                                             // 145
    //We're actually having mocha run all tests asynchronously. This                         // 146
    //is because mocha cannot tell when a synchronous fiber test has                         // 147
    //finished, because the test runner runs outside a fiber.                                // 148
                                                                                             // 149
    //It is possible that the mocha test runner could be run from within a                   // 150
    //fiber, but it was unclear to me how that could be done without                         // 151
    //forking mocha itself.                                                                  // 152
                                                                                             // 153
    global['it'] = function (name, func){                                                    // 154
      wrappedFunc = function(callback){                                                      // 155
        if (func.length == 0){                                                               // 156
          func();                                                                            // 157
          callback();                                                                        // 158
        }                                                                                    // 159
        else {                                                                               // 160
          func(callback);                                                                    // 161
        }                                                                                    // 162
      }                                                                                      // 163
                                                                                             // 164
      boundWrappedFunction = moddedBindEnvironment(wrappedFunc, function(err){               // 165
        throw err;                                                                           // 166
      });                                                                                    // 167
                                                                                             // 168
      mochaExports['it'](name, boundWrappedFunction);                                        // 169
    };                                                                                       // 170
                                                                                             // 171
    ["before", "beforeEach", "after", "afterEach"].forEach(function(testFunctionName){       // 172
      global[testFunctionName] = function (func){                                            // 173
        wrappedFunc = function(callback){                                                    // 174
          if (func.length == 0){                                                             // 175
            func();                                                                          // 176
            callback();                                                                      // 177
          }                                                                                  // 178
          else {                                                                             // 179
            func(callback);                                                                  // 180
          }                                                                                  // 181
        }                                                                                    // 182
                                                                                             // 183
        boundWrappedFunction = moddedBindEnvironment(wrappedFunc, function(err){             // 184
          throw err;                                                                         // 185
        });                                                                                  // 186
        mochaExports[testFunctionName](boundWrappedFunction);                                // 187
      }                                                                                      // 188
    });                                                                                      // 189
  }                                                                                          // 190
  function copyTestsToMirror(file){                                                          // 191
    Meteor.call("resetReports", {framework: "mocha-web-velocity"}, function(){               // 192
      var relativeDest = file.relativePath.split(path.sep).splice(1).join(path.sep);         // 193
      var mirrorPath = path.join(process.env.PWD, ".meteor", "local", ".mirror");            // 194
      var dest = path.join(mirrorPath, relativeDest);                                        // 195
      mkdirp.sync(dest);                                                                     // 196
      var cmd = "cp " +  file.absolutePath + " " + dest;                                     // 197
      childProcess.exec(cmd, function(err){                                                  // 198
        if (err) {                                                                           // 199
          console.error(err);                                                                // 200
        }                                                                                    // 201
      });                                                                                    // 202
    });                                                                                      // 203
  }                                                                                          // 204
                                                                                             // 205
  Meteor.startup(function(){                                                                 // 206
    VelocityTestFiles.find({targetFramework: 'mocha-web-velocity'}).observe({                // 207
      added: copyTestsToMirror,                                                              // 208
      changed: copyTestsToMirror,                                                            // 209
      removed: copyTestsToMirror                                                             // 210
    });                                                                                      // 211
  })                                                                                         // 212
}                                                                                            // 213
                                                                                             // 214
///////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mocha-web-velocity'] = {
  MochaWeb: MochaWeb,
  MeteorCollectionTestReporter: MeteorCollectionTestReporter
};

})();

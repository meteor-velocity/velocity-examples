(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var PackageStubber;

(function () {

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// packages/package-stubber/main.js                                                     //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
;(function () {                                                                         // 1
                                                                                        // 2
if ('undefined' === typeof PackageStubber) {                                            // 3
  PackageStubber = {}                                                                   // 4
}                                                                                       // 5
                                                                                        // 6
"use strict";                                                                           // 7
                                                                                        // 8
var pwd = process.env.PWD,                                                              // 9
    DEBUG = process.env.DEBUG,                                                          // 10
    fs = Npm.require('fs'),                                                             // 11
    path = Npm.require('path'),                                                         // 12
    glob = Npm.require('glob'),                                                         // 13
    _ = Npm.require('lodash'),                                                          // 14
    defaultPackagesToIgnore = [                                                         // 15
      'meteor-package-stubber',                                                         // 16
      'package-stubber',                                                                // 17
      'velocity',                                                                       // 18
      'mirror'                                                                          // 19
    ]                                                                                   // 20
                                                                                        // 21
_.extend(PackageStubber, {                                                              // 22
                                                                                        // 23
  /**                                                                                   // 24
   * The string used to replace functions found on stubbed objects.                     // 25
   *                                                                                    // 26
   * @property {String} functionReplacementStr                                          // 27
   */                                                                                   // 28
  functionReplacementStr: "function emptyFn () {}",                                     // 29
                                                                                        // 30
                                                                                        // 31
  /**                                                                                   // 32
   * Holds validation functions for class functions.                                    // 33
   *                                                                                    // 34
   * @property {Object} validate                                                        // 35
   */                                                                                   // 36
  validate: {                                                                           // 37
                                                                                        // 38
    /**                                                                                 // 39
     * Validate function arguments                                                      // 40
     *                                                                                  // 41
     * @method validate.stubPackages                                                    // 42
     */                                                                                 // 43
    stubPackages: function (options) {                                                  // 44
      if ('string' != typeof options.outfile) {                                         // 45
        throw new Error("[PackageStubber.stubPackages] If supplied, the " +             // 46
                        "'outfile' field must be the path to a file to write " +        // 47
                        "stub output to.  It can be an absolute path or " +             // 48
                        "relative to the current Meteor application")                   // 49
      }                                                                                 // 50
      if (typeof options.dontStub !== 'string' &&                                       // 51
          !_.isArray(options.dontStub)) {                                               // 52
        throw new Error("[PackageStubber.stubPackages] If supplied, the " +             // 53
                        "'dontStub' field must be the name of a package or an " +       // 54
                        "array of package names")                                       // 55
      }                                                                                 // 56
    },                                                                                  // 57
                                                                                        // 58
    /**                                                                                 // 59
     * Validate function arguments                                                      // 60
     *                                                                                  // 61
     * @method validate.deepCopyReplaceFn                                               // 62
     */                                                                                 // 63
    deepCopyReplaceFn: function (target, fnPlaceholder) {                               // 64
      if (null === target ||                                                            // 65
          'object' !== typeof target) {                                                 // 66
        throw new Error("[PackageStubber.deepCopyReplaceFn] Required field `target` " + // 67
                        "must be an object")                                            // 68
      }                                                                                 // 69
      if (null !== fnPlaceholder &&                                                     // 70
          'undefined' !== typeof fnPlaceholder &&                                       // 71
          'string' !== typeof fnPlaceholder) {                                          // 72
        throw new Error("[PackageStubber.deepCopyReplaceFn] If supplied, the " +        // 73
                        "'fnPlaceholder' field must be a string")                       // 74
      }                                                                                 // 75
    }                                                                                   // 76
                                                                                        // 77
  },  // end validate                                                                   // 78
                                                                                        // 79
                                                                                        // 80
  /**                                                                                   // 81
   * Create stubs for all smart packages in the current Meteor app.                     // 82
   * Stubs will be written to a javascript file.                                        // 83
   *                                                                                    // 84
   * NOTE: This function must be run in a Meteor app's context so that the              // 85
   * smart packages to stub are loaded and their object graphs can be traversed.        // 86
   *                                                                                    // 87
   * @method stubPackages                                                               // 88
   * @param {Object} options                                                            // 89
   *   @param {Array|String} [dontStub] Name(s) of package(s) to ignore (ie. not        // 90
   *                           stub).                                                   // 91
   *                           Default: []                                              // 92
   *   @param {String} [outfile] The file path to write the stubs to.                   // 93
   *                           Can be either an absolute file path or relative          // 94
   *                           to the current Meteor application.                       // 95
   *                           Default: `tests/a1-package-stubs.js`                     // 96
   */                                                                                   // 97
  stubPackages: function (options) {                                                    // 98
    var stubs = {},                                                                     // 99
        packagesToIgnore,                                                               // 100
        coreStubs,                                                                      // 101
        usedPackages,                                                                   // 102
        packageExports = [],                                                            // 103
        customStubs = [],                                                               // 104
        name,                                                                           // 105
        out = "";                                                                       // 106
                                                                                        // 107
    options = options || {}                                                             // 108
                                                                                        // 109
    options.outfile = options.outfile ||                                                // 110
                      path.join(pwd, 'tests', 'a1-package-stubs.js')                    // 111
    options.dontStub = options.dontStub || []                                           // 112
                                                                                        // 113
    PackageStubber.validate.stubPackages(options)                                       // 114
                                                                                        // 115
    if (options.outfile[0] !== path.sep) {                                              // 116
      options.outfile = path.join(pwd, options.outfile)                                 // 117
    }                                                                                   // 118
                                                                                        // 119
    if ('string' == typeof options.dontStub) {                                          // 120
      options.dontStub = [options.dontStub]                                             // 121
    }                                                                                   // 122
                                                                                        // 123
    // ignore test packages                                                             // 124
    packagesToIgnore = PackageStubber.listTestPackages()                                // 125
                                                                                        // 126
    // ignore defaults                                                                  // 127
    _.each(defaultPackagesToIgnore, function (packageName) {                            // 128
      packagesToIgnore.push(packageName)                                                // 129
    })                                                                                  // 130
                                                                                        // 131
    // ignore 'dontStub' packages                                                       // 132
    _.each(options.dontStub, function (packageName) {                                   // 133
      packagesToIgnore.push(packageName)                                                // 134
    })                                                                                  // 135
                                                                                        // 136
                                                                                        // 137
    // pull in all stubs for core packages.                                             // 138
    // these are always included since they are core and we have no way                 // 139
    // to detect their use (even .meteor/packages doesn't have a complete               // 140
    // list since dependencies don't show up there).                                    // 141
    coreStubs = glob.sync(path.join(pwd, 'packages',                                    // 142
                                    'package-stubber', 'core-stubs', "*.js"))           // 143
    _.each(coreStubs, function (filePath) {                                             // 144
      var packageName = path.basename(filePath, '.js')                                  // 145
                                                                                        // 146
      DEBUG && console.log('[PackageStubber] custom stub found for core package',       // 147
                           packageName)                                                 // 148
      packagesToIgnore.push(packageName)                                                // 149
      customStubs.push({                                                                // 150
        package: packageName,                                                           // 151
        filePath: filePath                                                              // 152
      })                                                                                // 153
    })                                                                                  // 154
                                                                                        // 155
                                                                                        // 156
    usedPackages = PackageStubber.listPackages()                                        // 157
                                                                                        // 158
    // check for custom stubs for community packages                                    // 159
    _.each(usedPackages, function (packageName) {                                       // 160
      var stubFile = packageName + ".js",                                               // 161
          stubFilePath = path.join(pwd, 'packages', 'package-stubber',                  // 162
                                   'community-stubs', stubFile)                         // 163
                                                                                        // 164
      if (fs.existsSync(stubFilePath)) {                                                // 165
        DEBUG && console.log('[PackageStubber] custom stub found for package',          // 166
                             packageName)                                               // 167
        packagesToIgnore.push(packageName)                                              // 168
        customStubs.push({                                                              // 169
          package: packageName,                                                         // 170
          filePath: stubFilePath                                                        // 171
        })                                                                              // 172
      }                                                                                 // 173
    })                                                                                  // 174
                                                                                        // 175
    // get list of package 'exports'                                                    // 176
    packageExports = PackageStubber.listPackageExports({                                // 177
                       packagesToIgnore: packagesToIgnore                               // 178
                     })                                                                 // 179
                                                                                        // 180
    // build stubs                                                                      // 181
    _.each(packageExports, function (exportInfo) {                                      // 182
      var name = exportInfo.name,                                                       // 183
          package = exportInfo.package,                                                 // 184
          toStub = global[name]                                                         // 185
                                                                                        // 186
      if (toStub) {                                                                     // 187
        DEBUG && console.log('[PackageStubber] stubbing', name,                         // 188
                             'in package', package)                                     // 189
        // `stubs` object will have one field of type `string` for each global          // 190
        // object that is being stubbed (ie. each package export)                       // 191
        stubs[name] = PackageStubber.generateStubJsCode(toStub, name, package)          // 192
      } else {                                                                          // 193
        DEBUG && console.log('[PackageStubber] ignored missing export', name,           // 194
                             'from package', package + ". NOTE: You may have" +         // 195
                             " to stub this export yourself if you " +                  // 196
                             "experience errors testing client-side code.")             // 197
      }                                                                                 // 198
    })                                                                                  // 199
                                                                                        // 200
    // prep for file write                                                              // 201
    for (name in stubs) {                                                               // 202
      out += "// " + name + "\n"                                                        // 203
      out += name + " = " + stubs[name] + ";\n\n"                                       // 204
    }                                                                                   // 205
                                                                                        // 206
    fs.writeFileSync(options.outfile, out)                                              // 207
                                                                                        // 208
    // append custom stubs                                                              // 209
    _.each(customStubs, function (stubConfig) {                                         // 210
      DEBUG && console.log('[PackageStubber] appending custom stub for package',        // 211
                           stubConfig.package)                                          // 212
      fs.appendFileSync(options.outfile, fs.readFileSync(stubConfig.filePath))          // 213
    })                                                                                  // 214
                                                                                        // 215
  },  // end stubPackages                                                               // 216
                                                                                        // 217
                                                                                        // 218
                                                                                        // 219
                                                                                        // 220
  /**                                                                                   // 221
   * Get the names of all test packages in a given Meteor application.                  // 222
   * Test packages are identified by having `testPackage: true` in their                // 223
   * `smart.json` file.                                                                 // 224
   *                                                                                    // 225
   * Used by PackageStubber to identify other packages to ignore.                       // 226
   *                                                                                    // 227
   * NOTE: Does not need to be run in a Meteor context.                                 // 228
   *                                                                                    // 229
   * @method listTestPackages                                                           // 230
   * @param {Object} [options]                                                          // 231
   *   @param {String} [appDir] Directory path of Meteor application to                 // 232
   *                            identify test packages for.                             // 233
   *                            Default: PWD (process working directory)                // 234
   * @return {Array} names of all test packages.                                        // 235
   *                 Ex. ['jasmine-unit', 'mocha-web-velocity']                         // 236
   */                                                                                   // 237
  listTestPackages: function (options) {                                                // 238
    var smartJsonFiles,                                                                 // 239
        names = []                                                                      // 240
                                                                                        // 241
    options = options || {}                                                             // 242
                                                                                        // 243
    options.appDir = normalizeAppDir(options)                                           // 244
                                                                                        // 245
    smartJsonFiles = glob.sync(path.join("**","smart.json"),                            // 246
                               {cwd: path.join(options.appDir, "packages")})            // 247
                                                                                        // 248
    _.each(smartJsonFiles, function (filePath) {                                        // 249
      var smartJson,                                                                    // 250
          fullPath = path.join(options.appDir, "packages", filePath);                   // 251
                                                                                        // 252
      try {                                                                             // 253
        smartJson = JSON.parse(fs.readFileSync(fullPath, 'utf8'))                       // 254
        if (smartJson && smartJson.testPackage) {                                       // 255
          names.push(path.dirname(filePath))                                            // 256
        }                                                                               // 257
      }                                                                                 // 258
      catch (ex) {                                                                      // 259
        DEBUG && console.log('[PackageStubber]', filePath, ex)                          // 260
      }                                                                                 // 261
    })                                                                                  // 262
                                                                                        // 263
    return names                                                                        // 264
  },  // end listTestPackages                                                           // 265
                                                                                        // 266
                                                                                        // 267
  /**                                                                                   // 268
   * List the names of all non-core packages used by the app.                           // 269
   *                                                                                    // 270
   * @method listPackages                                                               // 271
   * @param {Object} [options]                                                          // 272
   *   @param {String} [appDir] Directory path of Meteor application to                 // 273
   *                            identify package exports for.                           // 274
   *                            Default: PWD (process working directory)                // 275
   * @return {Array} names of all non-core packages used by app                         // 276
   */                                                                                   // 277
  listPackages: function (options) {                                                    // 278
    options = options || {}                                                             // 279
                                                                                        // 280
    options.appDir = normalizeAppDir(options)                                           // 281
                                                                                        // 282
    return ls (path.join(options.appDir, 'packages'))                                   // 283
  },                                                                                    // 284
                                                                                        // 285
                                                                                        // 286
  /**                                                                                   // 287
   * Get the names of all objects/functions which are exported by packages              // 288
   * in a Meteor application.                                                           // 289
   * Exports are identified by parsing each package's `package.js` file and             // 290
   * extracting out their `api.export(...)` calls.                                      // 291
   *                                                                                    // 292
   * Used by PackageStubber to identify which global objects to stub.                   // 293
   *                                                                                    // 294
   * NOTE: Does not need to be run in a Meteor context.                                 // 295
   *                                                                                    // 296
   * @method listPackageExports                                                         // 297
   * @param {Object} [options]                                                          // 298
   *   @param {String} [appDir] Directory path of Meteor application to                 // 299
   *                            identify package exports for.                           // 300
   *                            Default: PWD (process working directory)                // 301
   * @return {Array} list of info objects about package exports                         // 302
   *   ex. [{package: 'iron-router', name: 'RouteController'}, {...}]                   // 303
   */                                                                                   // 304
  listPackageExports: function (options) {                                              // 305
    var packageJsFiles,                                                                 // 306
        packageExports = [],                                                            // 307
        exportsRE = /api\.export\s*\(\s*(['"])(.*?)\1/igm;                              // 308
                                                                                        // 309
    options = options || {}                                                             // 310
                                                                                        // 311
    options.appDir = normalizeAppDir(options)                                           // 312
                                                                                        // 313
    packageJsFiles = glob.sync(path.join("**", "package.js"),                           // 314
                               {cwd: path.join(options.appDir, "packages")})            // 315
                                                                                        // 316
    _.each(packageJsFiles, function (filePath) {                                        // 317
      var package = path.dirname(filePath),                                             // 318
          file,                                                                         // 319
          found;                                                                        // 320
                                                                                        // 321
      if (PackageStubber.shouldIgnorePackage(options.packagesToIgnore, filePath)) {     // 322
        DEBUG && console.log('[PackageStubber] ignoring', package)                      // 323
        return                                                                          // 324
      }                                                                                 // 325
                                                                                        // 326
      try {                                                                             // 327
        file = fs.readFileSync(path.join(options.appDir, "packages", filePath), 'utf8') // 328
        while(found = exportsRE.exec(file)) {                                           // 329
          DEBUG && console.log('[PackageStubber] found', found[2], 'in', filePath)      // 330
          packageExports.push({                                                         // 331
            package: package,                                                           // 332
            name: found[2]                                                              // 333
          })                                                                            // 334
        }                                                                               // 335
      } catch (ex) {                                                                    // 336
        DEBUG && console.log('[PackageStubber] Error reading file', filePath, ex)       // 337
      }                                                                                 // 338
    })                                                                                  // 339
                                                                                        // 340
    return packageExports                                                               // 341
  },  // end listPackageExports                                                         // 342
                                                                                        // 343
                                                                                        // 344
  /**                                                                                   // 345
   * Performs a deep copy of the target object, replacing all function fields           // 346
   * with a string placeholder.                                                         // 347
   *                                                                                    // 348
   * @method deepCopyReplaceFn                                                          // 349
   * @param {Object} target The object that will be stubbed.                            // 350
   * @param {String} [fnPlaceholder] string to use in place of any function             // 351
   *                 fields.  Default: "FUNCTION_PLACEHOLDER"                           // 352
   * @return {Object} new object, with all functions replaced with the                  // 353
   *                  fnPlaceholder string                                              // 354
   */                                                                                   // 355
  deepCopyReplaceFn: function (target, fnPlaceholder) {                                 // 356
    var dest = {},                                                                      // 357
        fieldName,                                                                      // 358
        type                                                                            // 359
                                                                                        // 360
    PackageStubber.validate.deepCopyReplaceFn(target, fnPlaceholder)                    // 361
                                                                                        // 362
    fnPlaceholder = fnPlaceholder || "FUNCTION_PLACEHOLDER"                             // 363
                                                                                        // 364
    for (fieldName in target) {                                                         // 365
      type = typeof target[fieldName]                                                   // 366
      switch (type) {                                                                   // 367
        case "number":                                                                  // 368
          dest[fieldName] = target[fieldName]                                           // 369
          break;                                                                        // 370
        case "string":                                                                  // 371
          dest[fieldName] = target[fieldName]                                           // 372
          break;                                                                        // 373
        case "function":                                                                // 374
          dest[fieldName] = fnPlaceholder;                                              // 375
          break;                                                                        // 376
        case "object":                                                                  // 377
          if (target[fieldName] === null) {                                             // 378
            dest[fieldName] = null                                                      // 379
          } else if (target[fieldName] instanceof Date) {                               // 380
            dest[fieldName] = new Date(target[fieldName])                               // 381
          } else {                                                                      // 382
            dest[fieldName] = PackageStubber.deepCopyReplaceFn(                         // 383
                                                  target[fieldName],                    // 384
                                                  fnPlaceholder)                        // 385
          }                                                                             // 386
          break;                                                                        // 387
      }                                                                                 // 388
    }                                                                                   // 389
                                                                                        // 390
    return dest                                                                         // 391
  },  // end deepCopyReplaceFn                                                          // 392
                                                                                        // 393
                                                                                        // 394
  shouldIgnorePackage: function (packagesToIgnore, packagePath) {                       // 395
    return _.some(packagesToIgnore, function (packageName) {                            // 396
      return packagePath.indexOf(packageName) == 0                                      // 397
    })                                                                                  // 398
  },                                                                                    // 399
                                                                                        // 400
  /**                                                                                   // 401
   * Neither JSON.stringify() nor .toString() work for functions so we "stub"           // 402
   * functions by:                                                                      // 403
   *   1. replacing them with a placeholder string                                      // 404
   *   2. `JSON.stringify`ing the resulting object                                      // 405
   *   3. converting placeholders to empty function code in string form                 // 406
   *                                                                                    // 407
   * We need to do the string replacement in two steps because otherwise the            // 408
   * `JSON.stringify` step would escape our functions incorrectly.                      // 409
   *                                                                                    // 410
   * @method replaceFnPlaceholders                                                      // 411
   * @param {String} str String to convert                                              // 412
   * @param {String} [placeHolder] string to replace.                                   // 413
   *                 Default: "FUNCTION_PLACEHOLDER"                                    // 414
   * @param {String} [replacement] replacement for placeholder strings.                 // 415
   *                 Default: PackageStubber.functionReplacementStr                     // 416
   * @return {String} string with all placeholder strings replaced                      // 417
   *                  with `PackageStubber.functionReplacementStr`                      // 418
   */                                                                                   // 419
  replaceFnPlaceholders: function (str, placeholder, replacement) {                     // 420
    var regex                                                                           // 421
                                                                                        // 422
    placeholder = placeholder || '"FUNCTION_PLACEHOLDER"'                               // 423
    replacement = replacement || PackageStubber.functionReplacementStr                  // 424
                                                                                        // 425
    regex = new RegExp(placeholder, 'g')                                                // 426
                                                                                        // 427
    return str.replace(regex, replacement)                                              // 428
  },  // end replaceFnPlaceholders                                                      // 429
                                                                                        // 430
                                                                                        // 431
  stubGenerators: {                                                                     // 432
                                                                                        // 433
    /**                                                                                 // 434
     * Generates a stub in string form for function types.                              // 435
     *                                                                                  // 436
     * @method stubGenerators.function                                                  // 437
     * @param {Function} target Target function to stub                                 // 438
     * @param {String} name Name of target object for use in reporting errors           // 439
     * @param {String} package Name of target package for use in errors                 // 440
     * @return {String} Javascript code in string form which, when executed,            // 441
     *                  builds the stub in the then-current global context              // 442
     */                                                                                 // 443
    'function': function (target, name, package) {                                      // 444
      var stubInStringForm,                                                             // 445
          defaultReturnStr = PackageStubber.functionReplacementStr,                     // 446
          objStubber = PackageStubber.stubGenerators['object']                          // 447
                                                                                        // 448
      // Attempt to instantiate new constructor with no parameters.                     // 449
      //   ex. moment().format('MMM dd, YYYY')                                          // 450
      // Some packages have global function objects which throw an error                // 451
      // if no parameters are passed (ex. IronRouter's RouteController).                // 452
      // In this case, not much we can do.  Just alert the user and stub                // 453
      // with an empty function.                                                        // 454
                                                                                        // 455
      try {                                                                             // 456
        target = target()                                                               // 457
        stubInStringForm = objStubber(target, name, package)                            // 458
        stubInStringForm = "function () { return " + stubInStringForm + "; }"           // 459
        return stubInStringForm                                                         // 460
      } catch (ex) {                                                                    // 461
        console.log("[PackageStubber] Calling exported function '" +                    // 462
                    name + "' in package '" + package + "' with no parameters" +        // 463
                    " produced an error. " +                                            // 464
                    "'" + name + "' has been stubbed with an empty function " +         // 465
                    "but if you receive errors due to missing fields in " +             // 466
                    "this package, you will need to supply your own " +                 // 467
                    "custom stub. The original error was: ", ex.message)                // 468
        return defaultReturnStr                                                         // 469
      }                                                                                 // 470
    },                                                                                  // 471
                                                                                        // 472
    /**                                                                                 // 473
     * Generates a stub in string form for object types.                                // 474
     *                                                                                  // 475
     * @method stubGenerators.object                                                    // 476
     * @param {Object} target Target object to stub                                     // 477
     * @param {String} name Name of target object for use in reporting errors           // 478
     * @param {String} package Name of target package for use in errors                 // 479
     * @return {String} String representation of the target object.                     // 480
     */                                                                                 // 481
    'object': function (target, name, package) {                                        // 482
      var intermediateStub,                                                             // 483
          stubInStringForm,                                                             // 484
          defaultReturnStr = "{}"                                                       // 485
                                                                                        // 486
      try {                                                                             // 487
        intermediateStub = PackageStubber.deepCopyReplaceFn(target)                     // 488
        stubInStringForm = PackageStubber.replaceFnPlaceholders(                        // 489
                               JSON.stringify(intermediateStub, null, 2))               // 490
        return stubInStringForm                                                         // 491
      } catch (ex) {                                                                    // 492
        console.log("[PackageStubber] Error generating stub for exported " +            // 493
                    "object '" + name + " in package '" + package + "'. " +             // 494
                    name + "' has been " +                                              // 495
                    "stubbed with an empty object but if you receive " +                // 496
                    "errors due to missing fields in this package, you " +              // 497
                    "will need to supply your own custom stub. The " +                  // 498
                    "original error follows:\n", ex.message)                            // 499
        return defaultReturnStr                                                         // 500
      }                                                                                 // 501
    },                                                                                  // 502
                                                                                        // 503
    /**                                                                                 // 504
     * Generates a stub in string form for string types.                                // 505
     *                                                                                  // 506
     * @method stubGenerators.string                                                    // 507
     * @param {Object} target Target string to stub                                     // 508
     * @param {String} name Name of target string for use in reporting errors           // 509
     * @return {String} The original target string, passed through                      // 510
     */                                                                                 // 511
    'string': function (target, name) {                                                 // 512
      return target                                                                     // 513
    },                                                                                  // 514
                                                                                        // 515
    /**                                                                                 // 516
     * Generates a stub in string form for number types.                                // 517
     *                                                                                  // 518
     * @method stubGenerators.number                                                    // 519
     * @param {Object} target Target number to stub                                     // 520
     * @param {String} name Name of target number for use in reporting errors           // 521
     * @return {String} The original target number, converted to a string               // 522
     */                                                                                 // 523
    'number': function (target, name) {                                                 // 524
      return target.toString()                                                          // 525
    },                                                                                  // 526
                                                                                        // 527
    /**                                                                                 // 528
     * Generates a stub in string form for undefined targets.                           // 529
     *                                                                                  // 530
     * @method stubGenerators.undefined                                                 // 531
     * @return {String} "undefined"                                                     // 532
     */                                                                                 // 533
    'undefined': function () {                                                          // 534
      return 'undefined'                                                                // 535
    }                                                                                   // 536
                                                                                        // 537
  },  // end stubGenerators                                                             // 538
                                                                                        // 539
                                                                                        // 540
  /**                                                                                   // 541
   * Creates a stub of the target object or function.  Stub is in the form              // 542
   * of js code in string form which, when executed, builds the stubs in                // 543
   * the then-current global context.                                                   // 544
   *                                                                                    // 545
   * Useful when auto-stubbing Meteor packages and then running unit tests              // 546
   * in a new, Meteor-free context.                                                     // 547
   *                                                                                    // 548
   * @method generateStubJsCode                                                         // 549
   * @param {Any} target Target to stub                                                 // 550
   * @param {String} name Name thing to stub for use in reporting errors                // 551
   * @param {String} package Name of target package for use in errors                   // 552
   * @return {String} Javascript code in string form which, when executed,              // 553
   *                  builds the stub in the then-current global context                // 554
   */                                                                                   // 555
  generateStubJsCode: function (target, name, package) {                                // 556
    var typeOfTarget = typeof target,                                                   // 557
        stubGenerator                                                                   // 558
                                                                                        // 559
    if (null === target) {                                                              // 560
      // handle null special case since it has type "object"                            // 561
      return "null"                                                                     // 562
    }                                                                                   // 563
                                                                                        // 564
    // dispatch to generator function based on type of target                           // 565
                                                                                        // 566
    stubGenerator = PackageStubber.stubGenerators[typeOfTarget]                         // 567
                                                                                        // 568
    if (!stubGenerator) {                                                               // 569
      throw new Error("[PackageStubber] Could not stub package export '" +              // 570
                      name + "' in package '" + package + "'.  Missing stub " +         // 571
                      "generator for type", typeOfTarget)                               // 572
    }                                                                                   // 573
                                                                                        // 574
    return stubGenerator(target, name, package)                                         // 575
                                                                                        // 576
  }  // end generateStubJsCode                                                          // 577
                                                                                        // 578
})  // end _.extend PackageStubber                                                      // 579
                                                                                        // 580
                                                                                        // 581
                                                                                        // 582
/**                                                                                     // 583
 * List all non-hidden directories in target directory                                  // 584
 *                                                                                      // 585
 * @method ls                                                                           // 586
 * @return {Array} list of all non-hidden directories in target directory               // 587
 * @private                                                                             // 588
 */                                                                                     // 589
function ls (rootDir) {                                                                 // 590
  var files = fs.readdirSync(rootDir)                                                   // 591
                                                                                        // 592
  return _.reduce(files, function (memo, file) {                                        // 593
    var filePath,                                                                       // 594
        stat                                                                            // 595
                                                                                        // 596
    if (file[0] != '.') {                                                               // 597
      filePath = path.join(rootDir, file)                                               // 598
      stat = fs.statSync(filePath)                                                      // 599
                                                                                        // 600
      if (stat.isDirectory()) {                                                         // 601
        memo.push(file)                                                                 // 602
      }                                                                                 // 603
    }                                                                                   // 604
                                                                                        // 605
    return memo                                                                         // 606
  }, [])                                                                                // 607
}  // end ls                                                                            // 608
                                                                                        // 609
                                                                                        // 610
/**                                                                                     // 611
 * Normalizes path to application directory.                                            // 612
 * If `appDir` field is not set on `options` param,                                     // 613
 * uses PWD.                                                                            // 614
 *                                                                                      // 615
 * @method normalizeAppDir                                                              // 616
 * @param {Object} [options] Optional, options object containing an `appDir`            // 617
 *                           string field pointing to the target Meteor                 // 618
 *                           application to process.                                    // 619
 * @return {String} the normalized application directory                                // 620
 */                                                                                     // 621
function normalizeAppDir (options) {                                                    // 622
  var pwd = process.env.PWD                                                             // 623
                                                                                        // 624
  if (!options || 'string' !== typeof options.appDir) {                                 // 625
    return pwd                                                                          // 626
  }                                                                                     // 627
                                                                                        // 628
  if (options.appDir && options.appDir[0] !== path.sep) {                               // 629
    // relative path, prepend PWD                                                       // 630
    return path.join(pwd, options.appDir)                                               // 631
  }                                                                                     // 632
                                                                                        // 633
  return options.appDir                                                                 // 634
}  // end normalizeAppDir                                                               // 635
                                                                                        // 636
                                                                                        // 637
})();                                                                                   // 638
                                                                                        // 639
//////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['package-stubber'] = {
  PackageStubber: PackageStubber
};

})();

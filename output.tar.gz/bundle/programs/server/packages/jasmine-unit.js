(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var VelocityTestFiles = Package.velocity.VelocityTestFiles;
var VelocityTestReports = Package.velocity.VelocityTestReports;
var VelocityAggregateReports = Package.velocity.VelocityAggregateReports;
var VelocityLogs = Package.velocity.VelocityLogs;
var PackageStubber = Package['package-stubber'].PackageStubber;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/jasmine-unit/main.js                                                                             //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
;                                                                                                            // 1
(function () {                                                                                               // 2
                                                                                                             // 3
  "use strict";                                                                                              // 4
                                                                                                             // 5
  var ANNOUNCE_STRING = 'Velocity Jasmine-Unit is loaded',                                                   // 6
      pwd = process.env.PWD,                                                                                 // 7
      DEBUG = process.env.JASMINE_DEBUG,                                                                     // 8
      spawn = Npm.require('child_process').spawn,                                                            // 9
      parseString = Npm.require('xml2js').parseString,                                                       // 10
      glob = Npm.require('glob'),                                                                            // 11
      fs = Npm.require('fs'),                                                                                // 12
      path = Npm.require('path'),                                                                            // 13
      _ = Npm.require('lodash'),                                                                             // 14
      rimraf = Npm.require('rimraf'),                                                                        // 15
      testReportsPath = _p(pwd + '/tests/.reports/jasmine-unit'),                                            // 16
      args = [],                                                                                             // 17
      jasmineCli,                                                                                            // 18
      closeFunc;                                                                                             // 19
                                                                                                             // 20
  function _p (unixPath) {                                                                                   // 21
    return unixPath.replace('\/', path.sep);                                                                 // 22
  }                                                                                                          // 23
                                                                                                             // 24
// build OS-independent path to jasmine cli                                                                  // 25
  jasmineCli = _p(pwd + '/packages/jasmine-unit/.npm/package/node_modules/jasmine-node-reporter-fix/lib/jasmine-node/cli.js');
                                                                                                             // 27
  args.push(jasmineCli);                                                                                     // 28
  args.push('--coffee');                                                                                     // 29
  args.push('--color');                                                                                      // 30
  args.push('--verbose');                                                                                    // 31
  args.push('--match');                                                                                      // 32
  args.push('.*-jasmine-unit\.');                                                                            // 33
  args.push('--matchall');                                                                                   // 34
  args.push('--junitreport');                                                                                // 35
  args.push('--output');                                                                                     // 36
  args.push(testReportsPath);                                                                                // 37
  args.push(_p(pwd + '/packages/jasmine-unit/lib'));                                                         // 38
  args.push(_p(pwd + '/tests'));                                                                             // 39
                                                                                                             // 40
// How can we abstract this server-side so the test frameworks don't need to know about velocity collections // 41
  VelocityTestFiles.find({targetFramework: 'jasmine-unit'}).observe({                                        // 42
    added: rerunTests,                                                                                       // 43
    changed: rerunTests,                                                                                     // 44
    removed: rerunTests                                                                                      // 45
  });                                                                                                        // 46
                                                                                                             // 47
  console.log(ANNOUNCE_STRING);                                                                              // 48
                                                                                                             // 49
                                                                                                             // 50
                                                                                                             // 51
//////////////////////////////////////////////////////////////////////                                       // 52
// private functions                                                                                         // 53
//                                                                                                           // 54
                                                                                                             // 55
  function hashCode (s) {                                                                                    // 56
    return s.split("").reduce(function (a, b) {                                                              // 57
      a = ((a << 5) - a) + b.charCodeAt(0);                                                                  // 58
      return a & a;                                                                                          // 59
    }, 0);                                                                                                   // 60
  }                                                                                                          // 61
                                                                                                             // 62
  closeFunc = Meteor.bindEnvironment(function () {                                                           // 63
    var newResults = [],                                                                                     // 64
        globSearchString = _p('**/TEST-*.xml'),                                                              // 65
        xmlFiles = glob.sync(globSearchString, { cwd: testReportsPath });                                    // 66
                                                                                                             // 67
    _.each(xmlFiles, function (xmlFile, index) {                                                             // 68
      parseString(fs.readFileSync(testReportsPath + path.sep + xmlFile), function (err, result) {            // 69
        _.each(result.testsuites.testsuite, function (testsuite) {                                           // 70
          _.each(testsuite.testcase, function (testcase) {                                                   // 71
            var result = ({                                                                                  // 72
              name: testcase.$.name,                                                                         // 73
              framework: 'jasmine-unit',                                                                     // 74
              result: testcase.failure ? 'failed' : 'passed',                                                // 75
              timestamp: testsuite.$.timestamp,                                                              // 76
              time: testcase.$.time,                                                                         // 77
              ancestors: [testcase.$.classname]                                                              // 78
            });                                                                                              // 79
                                                                                                             // 80
            if (testcase.failure) {                                                                          // 81
              _.each(testcase.failure, function (failure) {                                                  // 82
                result.failureType = failure.$.type;                                                         // 83
                result.failureMessage = failure.$.message;                                                   // 84
                result.failureStackTrace = failure._;                                                        // 85
              });                                                                                            // 86
            }                                                                                                // 87
            result.id = 'jasmine-unit:' + hashCode(xmlFile + testcase.$.classname + testcase.$.name);        // 88
            newResults.push(result.id);                                                                      // 89
            Meteor.call('postResult', result);                                                               // 90
          });                                                                                                // 91
        });                                                                                                  // 92
      });                                                                                                    // 93
                                                                                                             // 94
      if (index === xmlFiles.length - 1) {                                                                   // 95
        Meteor.call('resetReports', {framework: 'jasmine-unit', notIn: newResults});                         // 96
        Meteor.call('completed', {framework: 'jasmine-unit'});                                               // 97
      }                                                                                                      // 98
    });                                                                                                      // 99
  });  // end closeFunc                                                                                      // 100
                                                                                                             // 101
  function rerunTests () {                                                                                   // 102
    Meteor.call('resetLogs', {framework: 'jasmine-unit'});                                                   // 103
    rimraf.sync(testReportsPath);                                                                            // 104
                                                                                                             // 105
    PackageStubber.stubPackages();                                                                           // 106
                                                                                                             // 107
    DEBUG && console.log('jasmine cli: ', process.execPath, args.join(' '));                                 // 108
                                                                                                             // 109
    var jasmineNode = spawn(process.execPath, args);                                                         // 110
    jasmineNode.stdout.pipe(process.stdout);                                                                 // 111
    jasmineNode.stderr.pipe(process.stderr);                                                                 // 112
    jasmineNode.on('close', closeFunc);                                                                      // 113
  }                                                                                                          // 114
                                                                                                             // 115
                                                                                                             // 116
})();                                                                                                        // 117
                                                                                                             // 118
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['jasmine-unit'] = {};

})();

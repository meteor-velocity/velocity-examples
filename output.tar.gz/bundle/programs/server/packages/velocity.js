(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var VelocityTestFiles, VelocityTestReports, VelocityAggregateReports, VelocityLogs;

(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/velocity/collections.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
VelocityTestFiles = new Meteor.Collection("velocityTestFiles");                                                        // 1
VelocityTestReports = new Meteor.Collection("velocityTestReports");                                                    // 2
VelocityAggregateReports = new Meteor.Collection("velocityAggregateReports");                                          // 3
VelocityLogs = new Meteor.Collection("velocityLogs");                                                                  // 4
                                                                                                                       // 5
if (!Package["autopublish"]) {                                                                                         // 6
  if (Meteor.isServer) {                                                                                               // 7
    Meteor.publish("VelocityTestFiles", function () {                                                                  // 8
      return VelocityTestFiles.find({});                                                                               // 9
    });                                                                                                                // 10
    Meteor.publish("VelocityTestReports", function () {                                                                // 11
      return VelocityTestReports.find({});                                                                             // 12
    });                                                                                                                // 13
    Meteor.publish("VelocityAggregateReports", function () {                                                           // 14
      return VelocityAggregateReports.find({});                                                                        // 15
    });                                                                                                                // 16
    Meteor.publish("VelocityLogs", function () {                                                                       // 17
      return VelocityLogs.find({});                                                                                    // 18
    });                                                                                                                // 19
  }                                                                                                                    // 20
                                                                                                                       // 21
  if (Meteor.isClient) {                                                                                               // 22
    Meteor.subscribe("VelocityTestFiles");                                                                             // 23
    Meteor.subscribe("VelocityTestReports");                                                                           // 24
    Meteor.subscribe("VelocityAggregateReports");                                                                      // 25
    Meteor.subscribe("VelocityLogs");                                                                                  // 26
  }                                                                                                                    // 27
}                                                                                                                      // 28
                                                                                                                       // 29
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/velocity/main.js                                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
"use strict";                                                                                                          // 1
                                                                                                                       // 2
if (!(process.env.NODE_ENV == "development")){                                                                         // 3
  // console.log("Not adding velocity code");                                                                          // 4
  return                                                                                                               // 5
}                                                                                                                      // 6
                                                                                                                       // 7
var _ = Npm.require('lodash'),                                                                                         // 8
    fs = Npm.require('fs'),                                                                                            // 9
    readFile = Meteor._wrapAsync(fs.readFile),                                                                         // 10
    writeFile = Meteor._wrapAsync(fs.writeFile),                                                                       // 11
    path = Npm.require('path'),                                                                                        // 12
    Rsync = Npm.require('rsync'),                                                                                      // 13
    child_process = Npm.require('child_process'),                                                                      // 14
    spawn = child_process.spawn,                                                                                       // 15
    fork = child_process.fork,                                                                                         // 16
    exec = Meteor._wrapAsync(child_process.exec),                                                                      // 17
    chokidar = Npm.require('chokidar'),                                                                                // 18
    glob = Npm.require('glob'),                                                                                        // 19
    DEBUG = !!process.env.VELOCITY_DEBUG,                                                                              // 20
    TEST_DIR = 'tests',                                                                                                // 21
    _config,                                                                                                           // 22
    _testFrameworks,                                                                                                   // 23
    watcher;                                                                                                           // 24
                                                                                                                       // 25
                                                                                                                       // 26
DEBUG && console.log('PWD', process.env.PWD);                                                                          // 27
                                                                                                                       // 28
_config = _loadTestPackageConfigs();                                                                                   // 29
_testFrameworks = _.pluck(_config, function (config) { return config.name; });                                         // 30
DEBUG && console.log('velocity config =', JSON.stringify(_config, null, 2));                                           // 31
                                                                                                                       // 32
if (!process.env.IS_MIRROR && (process.env.NODE_ENV == "development")) {                                               // 33
  // kick-off everything                                                                                               // 34
  _reset(_config);                                                                                                     // 35
} else {                                                                                                               // 36
  console.log("Not adding velocity code");                                                                             // 37
}                                                                                                                      // 38
                                                                                                                       // 39
                                                                                                                       // 40
                                                                                                                       // 41
//////////////////////////////////////////////////////////////////////                                                 // 42
// Meteor Methods                                                                                                      // 43
//                                                                                                                     // 44
                                                                                                                       // 45
Meteor.methods({                                                                                                       // 46
                                                                                                                       // 47
  /**                                                                                                                  // 48
   * Meteor method: reset                                                                                              // 49
   * Re-init file watcher and clear all test results.                                                                  // 50
   *                                                                                                                   // 51
   * @method reset                                                                                                     // 52
   */                                                                                                                  // 53
  reset: function () {                                                                                                 // 54
    _reset(_config);                                                                                                   // 55
  },                                                                                                                   // 56
                                                                                                                       // 57
  /**                                                                                                                  // 58
   * Meteor method: resetReports                                                                                       // 59
   * Clear all test results.                                                                                           // 60
   *                                                                                                                   // 61
   * @method resetReports                                                                                              // 62
   * @param {Object} [options] Optional, specify specific framework to clear                                           // 63
   *                 and/or define a list of tests to keep.                                                            // 64
   *                 ex.                                                                                               // 65
   *                 {                                                                                                 // 66
   *                   framework: "jasmine-unit",                                                                      // 67
   *                   notIn: ['tests/auth-jasmine-unit.js']                                                           // 68
   *                 }                                                                                                 // 69
   */                                                                                                                  // 70
  resetReports: function (options) {                                                                                   // 71
    var query = {};                                                                                                    // 72
    if (options.framework) {                                                                                           // 73
      query.framework = options.framework;                                                                             // 74
    }                                                                                                                  // 75
    if (options.notIn) {                                                                                               // 76
      query = _.assign(query, {_id: {$nin: options.notIn }});                                                          // 77
    }                                                                                                                  // 78
    VelocityTestReports.remove(query);                                                                                 // 79
    _updateAggregateReports();                                                                                         // 80
  },                                                                                                                   // 81
                                                                                                                       // 82
  /**                                                                                                                  // 83
   * Meteor method: resetLogs                                                                                          // 84
   * Clear all log entried.                                                                                            // 85
   *                                                                                                                   // 86
   * @method resetLogs                                                                                                 // 87
   * @param {Object} [options] Optional, specify specific framework to clear                                           // 88
   */                                                                                                                  // 89
  resetLogs: function (options) {                                                                                      // 90
    var query = {};                                                                                                    // 91
    if (options.framework) {                                                                                           // 92
      query.framework = options.framework;                                                                             // 93
    }                                                                                                                  // 94
    VelocityLogs.remove(query);                                                                                        // 95
  },                                                                                                                   // 96
                                                                                                                       // 97
  /**                                                                                                                  // 98
   * Meteor method: postLog                                                                                            // 99
   * Log a method to the central Velocity log store.                                                                   // 100
   *                                                                                                                   // 101
   * @method postLog                                                                                                   // 102
   * @param {Object} options Required parameters:                                                                      // 103
   *                   type - String                                                                                   // 104
   *                   message - String                                                                                // 105
   *                   framework - String  ex. 'jasmine-unit'                                                          // 106
   *                                                                                                                   // 107
   *                 Optional parameters:                                                                              // 108
   *                   timestamp - Date                                                                                // 109
   */                                                                                                                  // 110
  postLog: function (options) {                                                                                        // 111
    var requiredFields = ['type', 'message', 'framework'];                                                             // 112
                                                                                                                       // 113
    _checkRequired(requiredFields, options);                                                                           // 114
                                                                                                                       // 115
    VelocityLogs.insert({                                                                                              // 116
      timestamp: options.timestamp ? options.timestamp : Date.now(),                                                   // 117
      type: options.type,                                                                                              // 118
      message: options.message,                                                                                        // 119
      framework: options.framework                                                                                     // 120
    });                                                                                                                // 121
  },                                                                                                                   // 122
                                                                                                                       // 123
  /**                                                                                                                  // 124
   * Meteor method: postResult                                                                                         // 125
   * Record the results of a test run.                                                                                 // 126
   *                                                                                                                   // 127
   * @method postResult                                                                                                // 128
   * @param {Object} data Required fields:                                                                             // 129
   *                   id - String                                                                                     // 130
   *                   name - String                                                                                   // 131
   *                   framework - String  ex. 'jasmine-unit'                                                          // 132
   *                   result - String.  ex. 'failed', 'passed'                                                        // 133
   *                                                                                                                   // 134
   *                 Suggested fields:                                                                                 // 135
   *                   timestamp                                                                                       // 136
   *                   time                                                                                            // 137
   *                   async                                                                                           // 138
   *                   timeOut                                                                                         // 139
   *                   pending                                                                                         // 140
   *                   failureType                                                                                     // 141
   *                   failureMessage                                                                                  // 142
   *                   failureStackTrace                                                                               // 143
   *                   ancestors                                                                                       // 144
   */                                                                                                                  // 145
  postResult: function (data) {                                                                                        // 146
    var requiredFields = ['id', 'name', 'framework', 'result'];                                                        // 147
                                                                                                                       // 148
    data = data || {};                                                                                                 // 149
                                                                                                                       // 150
    _checkRequired(requiredFields, data);                                                                              // 151
                                                                                                                       // 152
    VelocityTestReports.upsert(data.id, {$set: data});                                                                 // 153
    _updateAggregateReports();                                                                                         // 154
  },  // end postResult                                                                                                // 155
                                                                                                                       // 156
  /**                                                                                                                  // 157
   * Meteor method: completed                                                                                          // 158
   * Frameworks must call this method to inform Velocity they have completed                                           // 159
   * their current test runs. Velocity uses this flag when running in CI mode.                                         // 160
   *                                                                                                                   // 161
   * @method completed                                                                                                 // 162
   * @param {Object} data Required fields:                                                                             // 163
   *                   framework - String  ex. 'jasmine-unit'                                                          // 164
   */                                                                                                                  // 165
  completed: function (data) {                                                                                         // 166
    var requiredFields = ['framework'];                                                                                // 167
                                                                                                                       // 168
    data = data || {};                                                                                                 // 169
                                                                                                                       // 170
    _checkRequired(requiredFields, data);                                                                              // 171
                                                                                                                       // 172
    VelocityAggregateReports.upsert({'name': data.framework}, {$set: {'result': 'completed'}});                        // 173
    _updateAggregateReports();                                                                                         // 174
  },  // end completed                                                                                                 // 175
                                                                                                                       // 176
                                                                                                                       // 177
  /**                                                                                                                  // 178
   * Meteor method: copySampleTests                                                                                    // 179
   * Copy sample tests from frameworks `sample-tests` directories                                                      // 180
   * to user's `app/tests` directory.                                                                                  // 181
   *                                                                                                                   // 182
   * @method copySampleTests                                                                                           // 183
   * @param {Object} options                                                                                           // 184
   *     ex. {framework: 'jasmine-unit'}                                                                               // 185
   */                                                                                                                  // 186
  copySampleTests: function (options) {                                                                                // 187
    var pwd = process.env.PWD,                                                                                         // 188
        samplesPath,                                                                                                   // 189
        testsPath,                                                                                                     // 190
        command;                                                                                                       // 191
                                                                                                                       // 192
    options = options || {};                                                                                           // 193
                                                                                                                       // 194
    if (!options.framework) {                                                                                          // 195
      return;                                                                                                          // 196
    }                                                                                                                  // 197
                                                                                                                       // 198
    samplesPath = path.join(pwd, 'packages', options.framework, 'sample-tests');                                       // 199
    testsPath = path.join(pwd, 'tests');                                                                               // 200
                                                                                                                       // 201
    DEBUG && console.log('[velocity] checking for sample tests in', path.join(samplesPath, '*'));                      // 202
                                                                                                                       // 203
    if (fs.existsSync(samplesPath)) {                                                                                  // 204
      command = 'mkdir -p ' + testsPath + ' && ' +                                                                     // 205
                'rsync -a ' + path.join(samplesPath, '*') +                                                            // 206
                          ' ' + testsPath + path.sep;                                                                  // 207
                                                                                                                       // 208
      DEBUG && console.log('[velocity] copying sample tests (if any) for framework', options.framework, '-', command); // 209
                                                                                                                       // 210
      child_process.exec(command, function (err, stdout, stderr) {                                                     // 211
        if (err) {                                                                                                     // 212
          console.log('ERROR', err);                                                                                   // 213
        }                                                                                                              // 214
        console.log(stdout);                                                                                           // 215
        console.log(stderr);                                                                                           // 216
      });                                                                                                              // 217
    }                                                                                                                  // 218
  }  // end copySampleTests                                                                                            // 219
                                                                                                                       // 220
                                                                                                                       // 221
});  // end Meteor methods                                                                                             // 222
                                                                                                                       // 223
                                                                                                                       // 224
                                                                                                                       // 225
                                                                                                                       // 226
//////////////////////////////////////////////////////////////////////                                                 // 227
// Private functions                                                                                                   // 228
//                                                                                                                     // 229
                                                                                                                       // 230
/**                                                                                                                    // 231
 * Ensures that each require field is found on the target object.                                                      // 232
 * Throws exception if a required field is undefined, null or an empty string.                                         // 233
 *                                                                                                                     // 234
 * @method _checkRequired                                                                                              // 235
 * @param {Array} requiredFields - list of required field names                                                        // 236
 * @param {Object} target - target object to check                                                                     // 237
 * @private                                                                                                            // 238
 */                                                                                                                    // 239
function _checkRequired (requiredFields, target) {                                                                     // 240
  _.each(requiredFields, function (name) {                                                                             // 241
    if (!target[name]) {                                                                                               // 242
      throw new Error("Required field '" + name + "' is missing." +                                                    // 243
        "Result not posted.")                                                                                          // 244
    }                                                                                                                  // 245
  })                                                                                                                   // 246
}                                                                                                                      // 247
                                                                                                                       // 248
                                                                                                                       // 249
                                                                                                                       // 250
/**                                                                                                                    // 251
 * Locate all velocity-compatible test packages and return their config                                                // 252
 * data.                                                                                                               // 253
 *                                                                                                                     // 254
 * @example                                                                                                            // 255
 *     // in `jasmine-unit` package's `smart.json`:                                                                    // 256
 *     {                                                                                                               // 257
 *       "name": "jasmine-unit",                                                                                       // 258
 *       "description": "Velocity-compatible jasmine unit test package",                                               // 259
 *       "homepage": "https://github.com/xolvio/jasmine-unit",                                                         // 260
 *       "author": "Sam Hatoum",                                                                                       // 261
 *       "version": "0.1.1",                                                                                           // 262
 *       "git": "https://github.com/xolvio/jasmine-unit.git",                                                          // 263
 *       "test-package": true,                                                                                         // 264
 *       "regex": "-jasmine-unit\\.(js|coffee)$"                                                                       // 265
 *     }                                                                                                               // 266
 *                                                                                                                     // 267
 * @method _loadTestPackageConfigs                                                                                     // 268
 * @return {Object} Hash of test package names and their normalized config data.                                       // 269
 * @private                                                                                                            // 270
 */                                                                                                                    // 271
function _loadTestPackageConfigs () {                                                                                  // 272
  var pwd = process.env.PWD,                                                                                           // 273
      smartJsons = glob.sync('packages/**/smart.json', {cwd: pwd}),                                                    // 274
      testConfigDictionary;                                                                                            // 275
                                                                                                                       // 276
  DEBUG && console.log('Check for test package configs...', smartJsons);                                               // 277
                                                                                                                       // 278
  testConfigDictionary = _.reduce(smartJsons, function (memo, smartJsonPath) {                                         // 279
    var contents,                                                                                                      // 280
        config;                                                                                                        // 281
                                                                                                                       // 282
    try {                                                                                                              // 283
      contents = readFile(path.join(pwd, smartJsonPath));                                                              // 284
      config = JSON.parse(contents);                                                                                   // 285
      if (config.name && config.testPackage) {                                                                         // 286
                                                                                                                       // 287
        // add smart.json contents to our dictionary                                                                   // 288
        memo[config.name] = config;                                                                                    // 289
                                                                                                                       // 290
        if ('undefined' === typeof memo[config.name].regex) {                                                          // 291
          // if test package hasn't defined an explicit regex for the file                                             // 292
          // watcher, default to the package name as a suffix.                                                         // 293
          // Ex. name = "mocha-web"                                                                                    // 294
          //     regex = "-mocha-web.js"                                                                               // 295
          memo[config.name].regex = '-' + config.name + '\\.js$';                                                      // 296
        }                                                                                                              // 297
                                                                                                                       // 298
        // create a regexp obj for use in file watching                                                                // 299
        memo[config.name]._regexp = new RegExp(memo[config.name].regex);                                               // 300
      }                                                                                                                // 301
    } catch (ex) {                                                                                                     // 302
      DEBUG && console.log('Error reading file:', smartJsonPath, ex);                                                  // 303
    }                                                                                                                  // 304
    return memo;                                                                                                       // 305
  }, {});                                                                                                              // 306
                                                                                                                       // 307
  return testConfigDictionary;                                                                                         // 308
}  // end _loadTestPackageConfigs                                                                                      // 309
                                                                                                                       // 310
                                                                                                                       // 311
/**                                                                                                                    // 312
 * Initialize the directory/file watcher.                                                                              // 313
 *                                                                                                                     // 314
 * @method _initWatcher                                                                                                // 315
 * @param {Object} config  See `_loadTestPackageConfigs`.                                                              // 316
 * @private                                                                                                            // 317
 */                                                                                                                    // 318
function _initWatcher (config) {                                                                                       // 319
  var testDir,                                                                                                         // 320
      _watcher;                                                                                                        // 321
                                                                                                                       // 322
  testDir = path.join(process.env.PWD, TEST_DIR);                                                                      // 323
                                                                                                                       // 324
  _watcher = chokidar.watch(testDir, {ignored: /[\/\\]\./});                                                           // 325
                                                                                                                       // 326
  _watcher.on('add', Meteor.bindEnvironment(function (filePath) {                                                      // 327
    var relativePath,                                                                                                  // 328
        targetFramework,                                                                                               // 329
        data;                                                                                                          // 330
                                                                                                                       // 331
    filePath = path.normalize(filePath);                                                                               // 332
                                                                                                                       // 333
    DEBUG && console.log('File added:', filePath);                                                                     // 334
                                                                                                                       // 335
    relativePath = filePath.substring(process.env.PWD.length);                                                         // 336
    if (relativePath[0] === path.sep) {                                                                                // 337
      relativePath = relativePath.substring(1);                                                                        // 338
    }                                                                                                                  // 339
                                                                                                                       // 340
    // test against each test framework's regexp matcher, use first                                                    // 341
    // one that matches                                                                                                // 342
    targetFramework = _.find(config, function (framework) {                                                            // 343
      return framework._regexp.test(relativePath);                                                                     // 344
    });                                                                                                                // 345
                                                                                                                       // 346
    if (targetFramework) {                                                                                             // 347
      DEBUG && console.log(targetFramework.name, ' <= ', filePath);                                                    // 348
                                                                                                                       // 349
      data = {                                                                                                         // 350
        _id: filePath,                                                                                                 // 351
        name: path.basename(filePath),                                                                                 // 352
        absolutePath: filePath,                                                                                        // 353
        relativePath: relativePath,                                                                                    // 354
        targetFramework: targetFramework.name,                                                                         // 355
        lastModified: Date.now()                                                                                       // 356
      };                                                                                                               // 357
                                                                                                                       // 358
      //DEBUG && console.log('data', data);                                                                            // 359
      VelocityTestFiles.insert(data);                                                                                  // 360
    }                                                                                                                  // 361
  }));  // end watcher.on 'add'                                                                                        // 362
                                                                                                                       // 363
  _watcher.on('change', Meteor.bindEnvironment(function (filePath) {                                                   // 364
    DEBUG && console.log('File changed:', filePath);                                                                   // 365
                                                                                                                       // 366
    // Since we key on filePath and we only add files we're interested in,                                             // 367
    // we don't have to worry about inadvertently updating records for files                                           // 368
    // we don't care about.                                                                                            // 369
    VelocityTestFiles.update(filePath, { $set: {lastModified: Date.now()}});                                           // 370
  }));                                                                                                                 // 371
                                                                                                                       // 372
  _watcher.on('unlink', Meteor.bindEnvironment(function (filePath) {                                                   // 373
    DEBUG && console.log('File removed:', filePath);                                                                   // 374
    // If we only remove the file, we also need to remove the test results for                                         // 375
    // just that file. This required changing the postResult API and we could                                          // 376
    // do it, but the brute force method of reset() will do the trick until we                                         // 377
    // want to optimize VelocityTestFiles.remove(filePath);                                                            // 378
    _reset(config);                                                                                                    // 379
  }));                                                                                                                 // 380
                                                                                                                       // 381
  return _watcher;                                                                                                     // 382
}  // end _initWatcher                                                                                                 // 383
                                                                                                                       // 384
                                                                                                                       // 385
/**                                                                                                                    // 386
 * Re-init file watcher and clear all test results.                                                                    // 387
 *                                                                                                                     // 388
 * @method _reset                                                                                                      // 389
 * @param {Object} config  See `_loadTestPackageConfigs`.                                                              // 390
 * @private                                                                                                            // 391
 */                                                                                                                    // 392
function _reset (config) {                                                                                             // 393
  if (watcher) {                                                                                                       // 394
    watcher.close();                                                                                                   // 395
  }                                                                                                                    // 396
                                                                                                                       // 397
  VelocityTestFiles.remove({});                                                                                        // 398
  VelocityTestReports.remove({});                                                                                      // 399
  VelocityLogs.remove({});                                                                                             // 400
  VelocityAggregateReports.remove({});                                                                                 // 401
  VelocityAggregateReports.insert({                                                                                    // 402
    name: 'aggregateResult',                                                                                           // 403
    result: 'pending'                                                                                                  // 404
  });                                                                                                                  // 405
  VelocityAggregateReports.insert({                                                                                    // 406
    name: 'aggregateComplete',                                                                                         // 407
    result: 'pending'                                                                                                  // 408
  });                                                                                                                  // 409
  _.each(_testFrameworks, function (testFramework) {                                                                   // 410
    VelocityAggregateReports.insert({                                                                                  // 411
      name: testFramework,                                                                                             // 412
      result: 'pending'                                                                                                // 413
    });                                                                                                                // 414
  });                                                                                                                  // 415
                                                                                                                       // 416
  // Meteor just reloaded us which means we should rsync the app files                                                 // 417
  _syncAndStartMirror();                                                                                               // 418
                                                                                                                       // 419
  watcher = _initWatcher(config);                                                                                      // 420
}                                                                                                                      // 421
                                                                                                                       // 422
/**                                                                                                                    // 423
 * If any one test has failed, mark the aggregate test result as failed.                                               // 424
 *                                                                                                                     // 425
 * @method _updateAggregateReports                                                                                     // 426
 * @private                                                                                                            // 427
 */                                                                                                                    // 428
function _updateAggregateReports () {                                                                                  // 429
                                                                                                                       // 430
  var failedResult,                                                                                                    // 431
      result;                                                                                                          // 432
                                                                                                                       // 433
  if (!VelocityTestReports.findOne({result: ''})) {                                                                    // 434
    failedResult = VelocityTestReports.findOne({result: 'failed'});                                                    // 435
    result = failedResult ? 'failed' : 'passed';                                                                       // 436
                                                                                                                       // 437
    VelocityAggregateReports.update({ 'name': 'aggregateResult'}, {$set: {result: result}});                           // 438
  }                                                                                                                    // 439
                                                                                                                       // 440
  // if all test frameworks have completed, upsert an aggregate completed record                                       // 441
  var completedFrameworksCount = VelocityAggregateReports.find({ 'name': {$in: _testFrameworks}, 'result': 'completed'}).count();
                                                                                                                       // 443
  if (_testFrameworks.length === completedFrameworksCount) {                                                           // 444
    VelocityAggregateReports.update({'name': 'aggregateComplete'}, {$set: {'result': 'completed'}});                   // 445
  }                                                                                                                    // 446
                                                                                                                       // 447
}                                                                                                                      // 448
                                                                                                                       // 449
function _startMirror () {                                                                                             // 450
  var mirrorBasePath = process.env.PWD + '/.meteor/local/.mirror'.split('/').join(path.sep);                           // 451
  var mongo_port = process.env.MONGO_URL.replace(/.*:(\d+).*/, '$1');                                                  // 452
  // start meteor on the mirror using a different port and different db schema                                         // 453
  var opts = {                                                                                                         // 454
    cwd: mirrorBasePath,                                                                                               // 455
    //      stdio: 'inherit',                                                                                          // 456
    stdio: 'ignore',                                                                                                   // 457
    env: _.extend({}, process.env, {                                                                                   // 458
      PORT: 5000,                                                                                                      // 459
      ROOT_URL: 'http://localhost:5000/',                                                                              // 460
      MONGO_URL: 'mongodb://127.0.0.1:' + mongo_port + '/mirror',                                                      // 461
      PARENT_URL: process.env.ROOT_URL,                                                                                // 462
      IS_MIRROR: true                                                                                                  // 463
    })                                                                                                                 // 464
  };                                                                                                                   // 465
  writeFile(mirrorBasePath + '/settings.json', JSON.stringify(Meteor.settings));                                       // 466
                                                                                                                       // 467
  console.log('Starting mirror on port 5000');                                                                         // 468
                                                                                                                       // 469
  spawn('meteor', ['--port', '5000', '--settings', 'settings.json'], opts);                                            // 470
}                                                                                                                      // 471
                                                                                                                       // 472
/**                                                                                                                    // 473
 * Creates a mirror of the application under .meteor/local/.mirror                                                     // 474
 * Any files with the pattern tests/.*  are not copied, this stops .report                                             // 475
 * directory from also being copied. The mirror is then started using  a node                                          // 476
 * fork                                                                                                                // 477
 *                                                                                                                     // 478
 * @method _syncAndStartMirror                                                                                         // 479
 * @private                                                                                                            // 480
 */                                                                                                                    // 481
function _syncAndStartMirror () {                                                                                      // 482
  var mirrorBasePath = process.env.PWD + '/.meteor/local/.mirror'.split('/').join(path.sep),                           // 483
  cmd = new Rsync()                                                                                                    // 484
    .shell('ssh')                                                                                                      // 485
    .flags('av')                                                                                                       // 486
    .set('delete')                                                                                                     // 487
    .set('q')                                                                                                          // 488
    .set('delay-updates')                                                                                              // 489
    .set('force')                                                                                                      // 490
    .exclude('.meteor/local')                                                                                          // 491
    .exclude('tests/.*')                                                                                               // 492
    .source(process.env.PWD + path.sep)                                                                                // 493
    .destination(mirrorBasePath);                                                                                      // 494
  var then = Date.now();                                                                                               // 495
  cmd.execute(Meteor.bindEnvironment(function (error, code, cmd) {                                                     // 496
    console.log('All done executing', cmd);                                                                            // 497
    console.log('rsync took', Date.now() - then);                                                                      // 498
                                                                                                                       // 499
    // TODO strip out velocity and html reporter from the mirror app                                                   // 500
                                                                                                                       // 501
    // TODO do magic here like callback frameworks to let them do what they need?                                      // 502
    // For now, only mocha-web tests are going to be copied outside the tests                                          // 503
    // directory so they can be watched by meteor                                                                      // 504
                                                                                                                       // 505
    _startMirror();                                                                                                    // 506
                                                                                                                       // 507
  }));                                                                                                                 // 508
}                                                                                                                      // 509
                                                                                                                       // 510
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.velocity = {
  VelocityTestFiles: VelocityTestFiles,
  VelocityTestReports: VelocityTestReports,
  VelocityAggregateReports: VelocityAggregateReports,
  VelocityLogs: VelocityLogs
};

})();
